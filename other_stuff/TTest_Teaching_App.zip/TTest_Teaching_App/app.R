# Statistical testing teaching app (version 5): unequal-group Welch / Student
# =====================================================================
# Dependencies: shiny only. All computations and plots use base R/stats.
# Run with shiny::runApp("app.R"). No internet access is required.
#
# Continuous outcomes: independent normal groups with separately chosen
# n_A, n_B, sigma_A, sigma_B, and true difference mu_B-mu_A.
# Welch is the primary two-sample mean test; optional pooled Student test.
# Power / type-I rejection curves are Monte Carlo estimates from simulated
# sufficient statistics, NOT a falsely 'exact' noncentral-t formula for
# Welch or pooled Student when variances differ.
# Wilcoxon: large-sample U-statistic approximation, including unequal n/SD.
# KS: Monte Carlo simulation. Nonparametric tests of FULL distributions
# may reject under unequal SD even when the means are identical.
# Confidence intervals: matched to each t-test, including Welch df.
# Other tabs retain independent chi-square, McNemar, and variance-ratio F.

if (!requireNamespace("shiny", quietly = TRUE)) {
  stop("Install the package first: install.packages('shiny')")
}
library(shiny)

# Colors are chosen for legibility and to avoid red-green comparisons.
col_A <- "#2563EB"      # blue
col_B <- "#D97706"      # amber
col_null <- "#475569"   # slate
col_p <- "#BE123C"      # rose: statistically significant
col_true <- "#7C3AED"   # violet: true parameter
col_wilcox <- "#087F8C" # teal: Wilcoxon rank-sum
col_ks <- "#9333EA"     # purple: Kolmogorov-Smirnov
col_student <- "#C2410C"  # orange: optional pooled Student test

# Simulate BOTH t-tests using normal-theory sampling distributions.
# For normal populations, sample means and sample variances are independent;
# (n-1)*s^2/sigma^2 ~ chi-square(n-1), exactly. The mean difference has
# distribution N(delta, sigma_A^2/n_A + sigma_B^2/n_B). Drawing these
# sufficient statistics instead of every individual is computationally
# faster and gives the SAME distribution of Welch and Student statistics
# as explicitly drawing each complete normal sample.
# Welch p-values / CIs use sample-specific Satterthwaite degrees of freedom.
# Pooled Student uses n_A+n_B-2 df; its null reference is not generally
# valid when sigma_A != sigma_B.
parametric_rejection_mc <- function(n_a, n_b, sigma_a, sigma_b,
                                    delta, alpha, repetitions = 20000L,
                                    seed = 20261210L) {
  set.seed(seed)
  v_a <- sigma_a^2 * rchisq(repetitions, df = n_a - 1) / (n_a - 1)
  v_b <- sigma_b^2 * rchisq(repetitions, df = n_b - 1) / (n_b - 1)
  diff <- delta + sqrt(sigma_a^2 / n_a + sigma_b^2 / n_b) *
    rnorm(repetitions)

  w_a <- v_a / n_a
  w_b <- v_b / n_b
  se_welch <- sqrt(w_a + w_b)
  df_welch <- (w_a + w_b)^2 /
    (w_a^2 / (n_a - 1) + w_b^2 / (n_b - 1))
  p_welch <- 2 * pt(-abs(diff / se_welch), df = df_welch)

  pooled <- ((n_a - 1) * v_a + (n_b - 1) * v_b) / (n_a + n_b - 2)
  se_student <- sqrt(pooled * (1 / n_a + 1 / n_b))
  p_student <- 2 * pt(-abs(diff / se_student), df = n_a + n_b - 2)

  c(welch = mean(p_welch < alpha), student = mean(p_student < alpha))
}

parametric_mc_repetitions <- 5000L
parametric_null_repetitions <- 10000L

# In the power panel x is TOTAL N (both groups). Group allocation is kept
# as close as possible to the current n_A:n_B ratio, with >=5 per group.
# The exact selected design is explicitly included in the grid.
power_designs <- function(n_a, n_b) {
  totals <- sort(unique(c(seq(10L, 600L, by = 15L), n_a + n_b)))
  fraction_a <- n_a / (n_a + n_b)
  a <- pmax(5L, pmin(totals - 5L, as.integer(round(totals * fraction_a))))
  b <- totals - a
  selected <- which(totals == n_a + n_b)
  a[selected] <- n_a
  b[selected] <- n_b
  data.frame(total = totals, a = a, b = b)
}

# Two-sided large-sample rank-sum power/rejection approximation for
# independent normal observations with ARBITRARY group sizes and SDs.
# U = sum_{i in B,j in A} I(B_i > A_j). Under unequal variances,
# a zero mean difference need not imply equal distributions: then the
# quantity is a rejection probability, not a type-I error for equality
# of population MEANS.
wilcoxon_power_normal <- function(n_a, n_b, delta, sigma_a, sigma_b, alpha) {
  theta <- pnorm(delta / sqrt(sigma_a^2 + sigma_b^2))
  # Probability that two pair indicators sharing the same A (or B)
  # observation both equal 1. These differ for unequal SDs.
  q_a <- integrate(function(z)
    pnorm((delta - sigma_a * z) / sigma_b)^2 * dnorm(z),
    lower = -9, upper = 9, rel.tol = 1e-7)$value
  q_b <- integrate(function(z)
    pnorm((delta + sigma_b * z) / sigma_a)^2 * dnorm(z),
    lower = -9, upper = 9, rel.tol = 1e-7)$value
  n_a <- as.numeric(n_a)
  n_b <- as.numeric(n_b)
  mean0 <- n_a * n_b / 2
  mean1 <- n_a * n_b * theta
  sd0 <- sqrt(n_a * n_b * (n_a + n_b + 1) / 12)
  var1 <- n_a * n_b * (theta * (1 - theta) +
    (n_b - 1) * pmax(0, q_a - theta^2) +
    (n_a - 1) * pmax(0, q_b - theta^2))
  sd1 <- sqrt(pmax(var1, 1e-12))
  z <- qnorm(1 - alpha / 2)
  lower <- mean0 - z * sd0
  upper <- mean0 + z * sd0
  pmin(1, pmax(0, pnorm(lower, mean = mean1, sd = sd1) +
                    pnorm(upper, mean = mean1, sd = sd1,
                          lower.tail = FALSE)))
}

# Overlapping area under two possibly unequal-SD normal densities.
normal_overlap <- function(delta, sigma_a, sigma_b) {
  if (delta == 0 && sigma_a == sigma_b) return(1)
  integrate(function(x)
    pmin(dnorm(x, mean = 0, sd = sigma_a),
         dnorm(x, mean = delta, sd = sigma_b)),
    lower = -Inf, upper = Inf, rel.tol = 1e-6)$value
}

# Empirical power of the two-sided, asymptotic two-sample KS test.
# KS tests equality of FULL distributions, not specifically means.
# We use a fixed random seed so moving a slider does not introduce a new
# random Monte Carlo run; a coarse grid limits waiting time.
ks_repetitions <- 350L

format_p <- function(p) {
  format.pval(p, digits = 3, eps = 0.0001)
}

plot_setup <- function() {
  par(
    mar = c(4.1, 4.2, 2.8, 0.9),
    mgp = c(2.4, 0.65, 0),
    cex.axis = 0.90,
    cex.lab = 0.95,
    bg = "white",
    las = 1
  )
}

metric_card <- function(title, value, subtext = NULL, accent = NULL) {
  tags$div(
    class = "metric-card",
    tags$div(class = "metric-label", title),
    tags$div(class = "metric-number", style = if (!is.null(accent))
      paste0("color:", accent, ";") else NULL, value),
    if (!is.null(subtext)) tags$div(class = "metric-sub", subtext)
  )
}

# ===========================================================================
# Version 4: categorical tests and a separate variance-ratio experiment.
# Each panel generates data appropriate for the test's DESIGN.
# - Pearson chi-square assumes independent observations and uses a 2x2 table.
# - Phi and Cramer's V are EFFECT SIZES, not additional significance tests.
# - McNemar uses PAIRED binary responses (not independent groups).
# - F-test compares variances of independent NORMAL populations.
# ===========================================================================

col_independent <- "#087F8C"  # teal: Pearson chi-square
col_corrected <- "#C2410C"    # orange: continuity correction
col_exact <- "#7C3AED"        # violet: exact binomial test
col_f <- "#1D4ED8"            # blue: F-test

power_grid_categorical <- unique(c(seq(5L, 300L, by = 10L), 300L))
mc_repetitions <- 2000L

# The standard 2x2 phi coefficient has a SIGN which depends on coding.
# For rows A, B and columns Yes, No, phi > 0 when p_A > p_B.
phi_2x2 <- function(tbl) {
  a <- tbl[1, 1]; b <- tbl[1, 2]
  c <- tbl[2, 1]; d <- tbl[2, 2]
  denom <- sqrt(prod(rowSums(tbl)) * prod(colSums(tbl)))
  if (denom <= 0) return(NA_real_)
  (a * d - b * c) / denom
}

# Pearson's chi-square and Yates-corrected chi-square, vectorized over 2x2
# equal-n independent tables. If one column has zero counts, there is no
# testable variability. Such experiments are treated as non-rejections in
# the POWER simulation (rather than silently dropping and biasing the rate).
chisq_rejections_2x2 <- function(a_yes, b_yes, n, alpha) {
  N <- 2 * n
  a <- a_yes; b <- n - a_yes; c <- b_yes; d <- n - b_yes
  denominator <- as.numeric(n)^2 * (a + c) * (b + d)
  good <- denominator > 0
  chi <- chi_y <- numeric(length(a))
  determinant <- a * d - b * c
  chi[good] <- N * determinant[good]^2 / denominator[good]
  chi_y[good] <- N * pmax(0, abs(determinant[good]) - N / 2)^2 /
    denominator[good]
  list(uncorrected = good & (pchisq(chi, df = 1, lower.tail = FALSE) < alpha),
       corrected = good & (pchisq(chi_y, df = 1, lower.tail = FALSE) < alpha))
}

# Null and alternative for McNemar are about paired DISCORDANCES:
#   b = A No / B Yes, c = A Yes / B No; H0: P(b) = P(c).
# Concordant pairs do not enter McNemar's statistic. Here r = P(b | discordant).
# Return three empirical rejection indicators. R's mcnemar.test(correct=TRUE)
# uses (abs(b-c)-1)^2/(b+c) when b+c > 0; we use the same expression.
mcnemar_rejections <- function(k, b, alpha) {
  c <- k - b
  good <- k > 0L
  stat <- stat_y <- numeric(length(k))
  stat[good] <- (b[good] - c[good])^2 / k[good]
  stat_y[good] <- (abs(b[good] - c[good]) - 1)^2 / k[good]
  p_exact <- pmin(1, 2 * pbinom(pmin(b, c), size = k, prob = 0.5))
  list(uncorrected = good & (pchisq(stat, df = 1, lower.tail = FALSE) < alpha),
       corrected = good & (pchisq(stat_y, df = 1, lower.tail = FALSE) < alpha),
       exact = (p_exact < alpha))
}

# Under independent normal observations the observed sample-variance ratio
# F = s_B^2/s_A^2 is distributed as ratio * F_(n-1,n-1).
# Two-sided rejection uses both tails of F under the null ratio=1.
power_f_variance <- function(n, variance_ratio, alpha) {
  df <- n - 1
  lower <- qf(alpha / 2, df, df)
  upper <- qf(1 - alpha / 2, df, df)
  pf(lower / variance_ratio, df, df) +
    pf(upper / variance_ratio, df, df, lower.tail = FALSE)
}

# This plot is shared conceptually by 2x2 Pearson chi-square and McNemar.
# All statistics are >= 0 and use an asymptotic chi-square(1) null reference.
plot_chi1_pvalues <- function(stats, names, colors, heading) {
  ok <- is.finite(stats)
  xmax <- max(8, if (any(ok)) min(25, max(stats[ok]) + 2) else 8)
  x <- seq(0.03, xmax, length.out = 650L)
  y <- dchisq(x, df = 1)
  plot_setup()
  plot(x, y, type = "l", col = col_null, lwd = 2.5,
       xlim = range(x), ylim = c(0, max(y) * 1.05),
       xlab = expression(chi^2 ~ "statistic"), ylab = "Null density",
       bty = "l", main = heading)
  if (any(ok)) {
    for (i in which(ok)) {
      abline(v = stats[i], col = colors[i], lty = if (i == 1) 1 else 2,
             lwd = 2.2)
    }
    legend("topright", legend = names[ok], col = colors[ok],
           lty = ifelse(which(ok) == 1, 1, 2), lwd = 2.2,
           bty = "n", cex = 0.74)
  } else {
    text(xmax / 2, max(y) / 2, "Statistic not estimable", cex = 0.95)
  }
}

# A plain HTML table avoids extra R package dependencies.
render_comparison_table <- function(column_headers, measures, rows) {
  tags$div(class = "test-table-wrap",
    tags$table(class = "test-table",
      tags$thead(tags$tr(
        tags$th(scope = "col", "Measure"),
        lapply(column_headers, function(x) tags$th(scope = "col", class = "test-col", x))
      )),
      tags$tbody(lapply(seq_along(measures), function(i)
        tags$tr(tags$th(scope = "row", measures[i]),
                lapply(rows[[i]], tags$td))
      ))
    )
  )
}

fmt_stat <- function(x, digits = 3) {
  if (length(x) == 0 || is.na(x) || !is.finite(x)) "Not estimable" else
    sprintf(paste0("%.", digits, "f"), x)
}
fmt_optional_p <- function(x) {
  if (length(x) == 0 || is.na(x) || !is.finite(x)) "Not estimable" else format_p(x)
}

ui <- fluidPage(
  tags$head(
    tags$style(HTML("
      body { background: #F8FAFC; color: #1E293B; }
      .page-heading { padding: 13px 0 9px; }
      .page-heading h2 { font-weight: 700; margin-bottom: 6px; }
      .page-heading p { color: #64748B; max-width: 1050px; }
      .well { background: #FFFFFF; border: 1px solid #E2E8F0;
              box-shadow: none; border-radius: 10px; }
      .chart-panel { background: #FFFFFF; border: 1px solid #E2E8F0;
                     border-radius: 10px; padding: 9px 11px 1px;
                     margin-bottom: 15px; }
      .chart-caption { font-size: 12px; line-height: 1.45;
                       color: #475569; min-height: 42px; margin-bottom: 11px; }
      .metric-grid { display: grid;
                     grid-template-columns: repeat(auto-fit, minmax(145px, 1fr));
                     gap: 9px; margin: 0 0 14px; }
      .metric-card { background: #FFFFFF; border: 1px solid #E2E8F0;
                     border-radius: 10px; padding: 11px 12px; }
      .metric-label { font-size: 12px; font-weight: 600; color: #64748B; }
      .metric-number { font-size: 24px; line-height: 1.3;
                       font-weight: 700; margin: 5px 0; }
      .metric-sub { font-size: 11px; line-height: 1.3; color: #64748B; }
      .explain-panel { background: #FFFFFF; border: 1px solid #E2E8F0;
                       border-radius: 10px; padding: 14px 17px;
                       line-height: 1.55; margin-bottom: 18px; }
      .explain-panel p { margin: 0 0 7px; }
      .explain-panel p:last-child { margin-bottom: 0; }
      .sidebar-title { font-weight: 700; margin-top: 0; }
      .controls-note { font-size: 12px; line-height: 1.5; color: #64748B; }
      .btn-default { border-radius: 7px; }
      .shiny-input-container { width: 100%; }
      .tab-content { padding-top: 15px; }
      .simulation-note { font-size: 12px; color: #475569; line-height: 1.55; }
      .legend-line { font-weight: bold; }
      .test-table { width: 100%; table-layout: fixed; border-collapse: collapse;
                    font-size: 13px; margin: 10px 0; }
      .test-table th, .test-table td { padding: 10px 9px;
                                      border: 1px solid #E2E8F0;
                                      vertical-align: top; overflow-wrap: break-word; }
      .test-table thead th { background: #F1F5F9; }
      .test-table tbody th { width: 20%; background: #F8FAFC; }
      .test-table .test-col { min-width: 130px; }
      .test-table-wrap { width: 100%; overflow-x: auto; }
      .test-note { font-size: 12px; line-height: 1.5; color: #475569; }
      @media (max-width: 767px) {
        .chart-caption { min-height: 0; }
      }
    "))
  ),
  div(
    class = "page-heading",
    h2("Understanding statistical tests, effect sizes and power"),
    p("Interactive experiments for continuous, categorical, paired, and variance outcomes: null hypotheses, test statistics, p-values, confidence intervals, effect sizes, and power")
  ),
  sidebarLayout(
    sidebarPanel(
      width = 3,
      h4(class = "sidebar-title", "Study settings"),
      conditionalPanel(
        condition = "input.main_tabs === 'Independent 2x2: chi-square' || input.main_tabs === 'McNemar: paired outcomes' || input.main_tabs === 'F-test: equal variances'",
        sliderInput("n", "Observations per group / number of pairs (n)",
                    min = 5, max = 300, value = 30, step = 5)
      ),
      sliderInput("alpha", "Significance threshold (alpha)",
                  min = 0.01, max = 0.10, value = 0.05, step = 0.01),
      conditionalPanel(
        condition = "input.main_tabs === 'Single study & power' || input.main_tabs === 'Repeated samples & CI coverage'",
        hr(), h4(class = "sidebar-title", "Continuous outcomes"),
        sliderInput("n_a", "Sample size, group A (n_A)",
                    min = 5, max = 300, value = 30, step = 5),
        sliderInput("n_b", "Sample size, group B (n_B)",
                    min = 5, max = 300, value = 30, step = 5),
        sliderInput("delta", "True mean difference (mu_B - mu_A)",
                    min = -4, max = 4, value = 1, step = 0.1),
        sliderInput("sigma_a", "Population SD, group A (sigma_A)",
                    min = 0.25, max = 4, value = 1.5, step = 0.05),
        sliderInput("sigma_b", "Population SD, group B (sigma_B)",
                    min = 0.25, max = 4, value = 1.5, step = 0.05),
        hr(), h4(class = "sidebar-title", "Compare statistical tests"),
        p(class = "controls-note", "Welch's t-test is always shown (R's t.test default)."),
        checkboxInput("show_student",
                      "Also show Student's pooled t-test (assumes equal variances)", FALSE),
        checkboxGroupInput(
          "extra_tests", "Nonparametric comparisons",
          choices = c("Wilcoxon rank-sum (Mann-Whitney)" = "wilcoxon",
                      "Kolmogorov-Smirnov (KS)" = "ks"),
          selected = "wilcoxon"
        ),
        p(class = "controls-note",
          "The tests use the SAME two independent samples. Mu_A = 0; mu_B = delta. With unequal SDs, Wilcoxon and KS test full-distribution differences, not equality of means.")
      ),
      conditionalPanel(
        condition = "input.main_tabs === 'F-test: equal variances'",
        sliderInput("sigma", "Population SD, group A (F-test only)",
                    min = 0.25, max = 4, value = 1.5, step = 0.05)
      ),
      conditionalPanel(
        condition = "input.main_tabs === 'Single study & power'",
        checkboxInput("show_obs", "Show observed values in plot 1", TRUE),
        actionButton("resample", "Draw a new random sample", width = "100%")
      ),
      conditionalPanel(
        condition = "input.main_tabs === 'Repeated samples & CI coverage'",
        hr(), h4(class = "sidebar-title", "Repeated sampling"),
        selectInput("replicates", "Number of independent experiments",
                    choices = c(10, 20, 50, 100, 200, 500, 1000),
                    selected = 100),
        checkboxInput("show_all_ci",
                      "Show ALL intervals (makes the plot very tall)", FALSE),
        actionButton("rerun_coverage", "Draw a NEW batch of experiments",
                     width = "100%"),
        p(class = "controls-note",
          "Welch CIs are shown by default. Enable Student above to overlay its CIs for the SAME experiments. All experiments count in the summary.")
      ),
      conditionalPanel(
        condition = "input.main_tabs === 'Independent 2x2: chi-square'",
        hr(), h4(class = "sidebar-title", "Independent binary outcomes"),
        sliderInput("prob_a", "True P(Yes) in group A", min = 0.05,
                    max = 0.95, value = 0.35, step = 0.05),
        sliderInput("prob_b", "True P(Yes) in group B", min = 0.05,
                    max = 0.95, value = 0.60, step = 0.05),
        actionButton("resample_categorical", "Draw new independent groups",
                     width = "100%"),
        p(class = "controls-note",
          "Each group contains n different participants. Pearson chi-square and Yates-corrected chi-square analyze the SAME observed 2x2 table. Phi and Cramer's V are effect sizes, not tests.")
      ),
      conditionalPanel(
        condition = "input.main_tabs === 'McNemar: paired outcomes'",
        hr(), h4(class = "sidebar-title", "Paired binary outcomes"),
        sliderInput("paired_discordance", "Probability of a discordant pair",
                    min = 0.05, max = 0.80, value = 0.30, step = 0.05),
        sliderInput("paired_direction", "P(A No, B Yes | discordant)",
                    min = 0.05, max = 0.95, value = 0.70, step = 0.05),
        sliderInput("paired_concordance", "P(both Yes | concordant)",
                    min = 0.05, max = 0.95, value = 0.50, step = 0.05),
        actionButton("resample_paired", "Draw new paired observations",
                     width = "100%"),
        p(class = "controls-note",
          "n is the number of PAIRS, not n per group. McNemar tests marginal equality through discordant pairs; Pearson chi-square for independent groups is NOT appropriate here.")
      ),
      conditionalPanel(
        condition = "input.main_tabs === 'F-test: equal variances'",
        hr(), h4(class = "sidebar-title", "Variance comparison"),
        sliderInput("f_ratio", "True variance ratio (Var B / Var A)",
                    min = 0.25, max = 4, value = 2, step = 0.05),
        actionButton("resample_f", "Draw new normal samples",
                     width = "100%"),
        p(class = "controls-note",
          "Two independent normal populations have equal means and SD(A) = sigma; SD(B) = sigma * sqrt(variance ratio). Two-sided F-test; n observations in EACH group.")
      ),
      hr(),
      p(class = "controls-note",
        "All simulations run locally. Continuous-data parametric power and null-rejection curves use Monte Carlo sufficient-statistic simulations; F-test power is exact under normality. Avoid choosing the test by whichever p-value is smaller.")
    ),
    mainPanel(
      width = 9,
      tabsetPanel(
        id = "main_tabs",
        tabPanel(
          "Single study & power",
          uiOutput("metrics"),
          fluidRow(
            column(
              width = 6,
              div(class = "chart-panel",
                  plotOutput("population_plot", height = "310px"),
                  p(class = "chart-caption",
                    "Population distributions of individual observations. The gray region is their overlap. Changing n alone does not change either distribution."))
            ),
            column(
              width = 6,
              div(class = "chart-panel",
                  plotOutput("sampling_plot", height = "310px"),
                  p(class = "chart-caption",
                    "Exact normal sampling distributions of the difference in means, with SE = sqrt(sigma_A^2/n_A + sigma_B^2/n_B). This SE decreases with increasing group sizes."))
            )
          ),
          fluidRow(
            column(
              width = 6,
              div(class = "chart-panel",
                  plotOutput("pvalue_plot", height = "310px"),
                  p(class = "chart-caption",
                    "Welch t reference distribution under H0 (using estimated Satterthwaite df). Rose tails give its approximate two-sided p-value."))
            ),
            column(
              width = 6,
              div(class = "chart-panel",
                  plotOutput("power_plot", height = "310px"),
                  p(class = "chart-caption",
                    "Welch and optional Student rejection curves are Monte Carlo estimates under the specified true normal populations. Wilcoxon is approximate; KS is simulated. The dot marks your selected group sizes."),
                  uiOutput("power_method_note"))
            )
          ),
          uiOutput("interpretation"),
          uiOutput("null_error_panel")
        ),
        tabPanel(
          "Repeated samples & CI coverage",
          uiOutput("coverage_metrics"),
          div(
            class = "chart-panel",
            uiOutput("ci_plot_ui"),
            div(class = "simulation-note", textOutput("ci_plot_context")),
            p(class = "simulation-note",
              tags$span(class = "legend-line", style = paste0("color:", col_A, ";"),
                        "Blue interval"), " = covers the true difference; ",
              tags$span(class = "legend-line", style = paste0("color:", col_B, ";"),
                        "orange interval"), " = misses the true difference. ",
              tags$span(class = "legend-line", style = paste0("color:", col_p, ";"),
                        "Filled rose dot"), " = statistically significant (p < alpha). ",
              "An open dot = not significant. Dashed violet line = true difference; ",
              "dotted gray line = null value (0). When Student is enabled, its intervals are drawn dashed just below Welch's solid intervals."
            )
          ),
          div(
            class = "chart-panel",
            plotOutput("running_rates_plot", height = "350px"),
            p(class = "chart-caption",
              "Cumulative CI coverage and rejection frequency for Welch, plus Student if enabled. Dotted reference lines show nominal confidence and simulated rejection probabilities.")
          ),
          p(class = "test-note",
            "Both t confidence intervals estimate the same MEAN difference. Under unequal SD, pooled Student intervals can have wrong coverage, especially with unequal n. Wilcoxon and KS do not share these intervals."),
          uiOutput("coverage_interpretation")
        ),
        tabPanel(
          "Independent 2x2: chi-square",
          uiOutput("categorical_metrics"),
          fluidRow(
            column(6, div(class = "chart-panel",
              h4("Observed 2x2 table"),
              tableOutput("categorical_table"),
              p(class = "chart-caption",
                "Independent participants; columns indicate a binary outcome. Counts and expected frequencies determine whether the chi-square approximation is trustworthy."))),
            column(6, div(class = "chart-panel",
              plotOutput("categorical_bar_plot", height = "290px"),
              p(class = "chart-caption",
                "Observed outcome proportions versus the true population probabilities, for two independent groups.")))
          ),
          fluidRow(
            column(6, div(class = "chart-panel",
              plotOutput("categorical_null_plot", height = "300px"),
              p(class = "chart-caption",
                "Approximate chi-square(1) null reference; vertical lines mark the test statistics with and without Yates correction."))),
            column(6, div(class = "chart-panel",
              plotOutput("categorical_power_plot", height = "300px"),
              p(class = "chart-caption",
                "Empirical power estimated from repeated independent 2x2 experiments. The simulation includes samples where a test cannot be performed (counted as non-rejections).")))
          ),
          uiOutput("categorical_interpretation")
        ),
        tabPanel(
          "McNemar: paired outcomes",
          uiOutput("paired_metrics"),
          fluidRow(
            column(6, div(class = "chart-panel",
              h4("Observed paired 2x2 table"),
              tableOutput("paired_table"),
              p(class = "chart-caption",
                "Rows: response at time A. Columns: response at time B. The two OFF-diagonal cells are discordant pairs."))),
            column(6, div(class = "chart-panel",
              plotOutput("paired_counts_plot", height = "290px"),
              p(class = "chart-caption",
                "Only switches from No to Yes versus Yes to No carry information for McNemar's equality-of-marginals test.")))
          ),
          fluidRow(
            column(6, div(class = "chart-panel",
              plotOutput("paired_null_plot", height = "300px"),
              p(class = "chart-caption",
                "Chi-square(1) reference for asymptotic McNemar p-values. For few discordant pairs, compare with the exact binomial p-value."))),
            column(6, div(class = "chart-panel",
              plotOutput("paired_power_plot", height = "300px"),
              p(class = "chart-caption",
                "Monte Carlo power for uncorrected, corrected and exact McNemar. Curves use the same simulated discordant-pair counts.")))
          ),
          uiOutput("paired_interpretation")
        ),
        tabPanel(
          "F-test: equal variances",
          uiOutput("f_metrics"),
          fluidRow(
            column(6, div(class = "chart-panel",
              plotOutput("f_density_plot", height = "300px"),
              p(class = "chart-caption",
                "Normal populations have equal means but may differ in SD; a sample estimate of variance is noisy, particularly at small n."))),
            column(6, div(class = "chart-panel",
              plotOutput("f_null_plot", height = "300px"),
              p(class = "chart-caption",
                "F distribution under equal variances. The two tails outside critical values form the two-sided rejection region.")))
          ),
          div(class = "chart-panel",
            plotOutput("f_power_plot", height = "330px"),
            p(class = "chart-caption",
              "Exact two-sided F-test power under independent normal samples. The population variance ratio, not the absolute sigma, determines power.")),
          uiOutput("f_interpretation")
        )
      )
    )
  )
)

server <- function(input, output, session) {

  # Identical latent standard-normal observations persist while students move
  # a slider; only the 'new sample' button changes the random draw.
  standard_draws <- reactive({
    set.seed(20261123 + input$resample)
    list(A = rnorm(300L), B = rnorm(300L))
  })

  samples <- reactive({
    z <- standard_draws()
    list(A = input$sigma_a * z$A[seq_len(input$n_a)],
         B = input$delta + input$sigma_b * z$B[seq_len(input$n_b)])
  })

  result <- reactive({
    s <- samples()
    welch <- t.test(s$B, s$A, alternative = "two.sided",
                    var.equal = FALSE, conf.level = 1 - input$alpha)
    student <- t.test(s$B, s$A, alternative = "two.sided",
                      var.equal = TRUE, conf.level = 1 - input$alpha)
    list(
      welch = welch, student = student,
      observed_diff = mean(s$B) - mean(s$A),
      theoretical_se = sqrt(input$sigma_a^2 / input$n_a +
                            input$sigma_b^2 / input$n_b),
      overlap = normal_overlap(input$delta, input$sigma_a, input$sigma_b),
      standardized_diff = input$delta /
        sqrt((input$sigma_a^2 + input$sigma_b^2) / 2)
    )
  })

  # Each optional test analyzes precisely the SAME samples as Welch.
  extra_results <- reactive({
    chosen <- input$extra_tests
    if (length(chosen) == 0L) return(list())
    s <- samples()
    ans <- list()
    if ("wilcoxon" %in% chosen) {
      ans$wilcoxon <- wilcox.test(s$B, s$A, alternative = "two.sided",
                                 exact = FALSE, correct = FALSE)
    }
    if ("ks" %in% chosen) {
      ans$ks <- suppressWarnings(ks.test(s$B, s$A,
                              alternative = "two.sided", exact = FALSE))
    }
    ans
  })

  # Reference curve for Welch and optional Student. Their observed rejection
  # rates are Monte Carlo estimates, so distorted type-I error becomes visible
  # for the pooled Student test under unequal SDs and n's.
  power_curves <- reactive({
    design <- power_designs(input$n_a, input$n_b)
    estimates <- matrix(NA_real_, nrow = nrow(design), ncol = 2L,
                        dimnames = list(NULL, c("welch", "student")))
    shiny::withProgress(message = "Simulating Welch and Student rejection rates",
                        value = 0, {
      for (i in seq_len(nrow(design))) {
        estimates[i, ] <- parametric_rejection_mc(
          design$a[i], design$b[i], input$sigma_a, input$sigma_b,
          input$delta, input$alpha, repetitions = parametric_mc_repetitions,
          seed = 20261220L + i)
        shiny::incProgress(1 / nrow(design))
      }
    })
    list(design = design, estimates = estimates,
         selected = which(design$total == input$n_a + input$n_b))
  })

  # Independently estimate Type I error under the TRUE null (delta = 0).
  # This depends on the variance and sample-size balance, but deliberately
  # does NOT depend on the 'true difference' slider.
  null_rejection <- reactive({
    parametric_rejection_mc(
      input$n_a, input$n_b, input$sigma_a, input$sigma_b,
      delta = 0, alpha = input$alpha,
      repetitions = parametric_null_repetitions, seed = 20261225L)
  })

  wilcoxon_powers <- reactive({
    req("wilcoxon" %in% input$extra_tests)
    d <- power_designs(input$n_a, input$n_b)
    wilcoxon_power_normal(d$a, d$b, input$delta,
                          input$sigma_a, input$sigma_b, input$alpha)
  })

  # Expensive KS simulations run only when the user selects KS.
  # The selected sample size is included exactly; no interpolation needed
  # to show its own rejection probability in the comparison table.
  ks_power_results <- reactive({
    req("ks" %in% input$extra_tests)
    design <- power_designs(input$n_a, input$n_b)
    idx <- sort(unique(c(seq(1L, nrow(design), by = 2L),
                         which(design$total == input$n_a + input$n_b))))
    d <- design[idx, , drop = FALSE]
    estimates <- numeric(nrow(d))
    set.seed(20261127)
    shiny::withProgress(message = "Simulating Kolmogorov-Smirnov rejection rates",
                        value = 0, {
      for (i in seq_len(nrow(d))) {
        rejected <- logical(ks_repetitions)
        for (j in seq_len(ks_repetitions)) {
          a <- input$sigma_a * rnorm(d$a[i])
          b <- input$delta + input$sigma_b * rnorm(d$b[i])
          rejected[j] <- suppressWarnings(ks.test(
            b, a, alternative = "two.sided", exact = FALSE)$p.value) < input$alpha
        }
        estimates[i] <- mean(rejected)
        shiny::incProgress(1 / nrow(d))
      }
    })
    list(n = d$total, power = estimates, repetitions = ks_repetitions)
  })

  ks_power_at_n <- reactive({
    x <- ks_power_results()
    as.numeric(x$power[which(x$n == input$n_a + input$n_b)])
  })

  # A batch of independent studies. Each row = one study. Fixed random
  # numbers permit paired comparisons between methods and slider settings.
  coverage_base_draws <- reactive({
    set.seed(20261124 + input$rerun_coverage)
    list(A = matrix(rnorm(1000L * 300L), nrow = 1000L, ncol = 300L),
         B = matrix(rnorm(1000L * 300L), nrow = 1000L, ncol = 300L))
  })

  coverage_results <- reactive({
    z <- coverage_base_draws()
    m <- as.integer(input$replicates)
    n_a <- input$n_a
    n_b <- input$n_b
    delta <- input$delta
    alpha <- input$alpha
    a <- input$sigma_a * z$A[seq_len(m), seq_len(n_a), drop = FALSE]
    b <- delta + input$sigma_b * z$B[seq_len(m), seq_len(n_b), drop = FALSE]
    mean_a <- rowMeans(a)
    mean_b <- rowMeans(b)
    var_a <- rowSums((a - mean_a)^2) / (n_a - 1)
    var_b <- rowSums((b - mean_b)^2) / (n_b - 1)
    est <- mean_b - mean_a

    # Exactly the formulas of R's t.test: Welch's degrees of freedom vary
    # between studies because each study estimates the two variances anew.
    w_a <- var_a / n_a
    w_b <- var_b / n_b
    welch_se <- sqrt(w_a + w_b)
    welch_df <- (w_a + w_b)^2 /
      (w_a^2 / (n_a - 1) + w_b^2 / (n_b - 1))
    pooled <- ((n_a - 1) * var_a + (n_b - 1) * var_b) /
      (n_a + n_b - 2)
    student_se <- sqrt(pooled * (1 / n_a + 1 / n_b))
    student_df <- n_a + n_b - 2

    make_method <- function(se, df) {
      t_stat <- est / se
      p_values <- 2 * pt(-abs(t_stat), df = df)
      t_crit <- qt(1 - alpha / 2, df = df)
      lower <- est - t_crit * se
      upper <- est + t_crit * se
      list(lower = lower, upper = upper, se = se, df = df,
           p_values = p_values, covered = (lower <= delta & delta <= upper),
           significant = (p_values < alpha))
    }
    list(m = m, n_a = n_a, n_b = n_b, delta = delta, alpha = alpha,
         estimated_diff = est,
         welch = make_method(welch_se, welch_df),
         student = make_method(student_se, student_df))
  })

  output$metrics <- renderUI({
    r <- result()
    mc <- power_curves()
    rate <- mc$estimates[mc$selected, ]
    is_sig <- r$welch$p.value < input$alpha
    div(class = "metric-grid",
      metric_card("Welch p-value", format_p(r$welch$p.value),
                  if (is_sig) "p < alpha (significant)" else "p >= alpha (not significant)",
                  if (is_sig) col_p else col_null),
      metric_card("Welch rejection probability", sprintf("%.1f%%", 100 * rate["welch"]),
                  "Monte Carlo; power if true delta differs from 0"),
      if (isTRUE(input$show_student))
        metric_card("Student rejection probability",
                    sprintf("%.1f%%", 100 * rate["student"]),
                    "May exceed alpha under H0 if variances differ", col_student),
      metric_card("Population overlap", sprintf("%.1f%%", 100 * r$overlap),
                  "Shared area under both individual-level curves"),
      metric_card("True SE of mean difference", sprintf("%.3f", r$theoretical_se),
                  "sqrt(sigma_A^2/n_A + sigma_B^2/n_B)"),
      metric_card("Observed mean difference", sprintf("%+.3f", r$observed_diff),
                  "Sample mean B minus sample mean A"),
      metric_card("Standardized true difference", sprintf("%+.2f", r$standardized_diff),
                  "Delta / sqrt((sigma_A^2 + sigma_B^2)/2)")
    )
  })

  output$population_plot <- renderPlot({
    s <- samples()
    delta <- input$delta
    sigma_a <- input$sigma_a
    sigma_b <- input$sigma_b
    width <- max(sigma_a, sigma_b)
    x <- seq(min(0, delta) - 4.2 * width,
             max(0, delta) + 4.2 * width, length.out = 650L)
    y_a <- dnorm(x, mean = 0, sd = sigma_a)
    y_b <- dnorm(x, mean = delta, sd = sigma_b)
    ymax <- max(y_a, y_b)

    plot_setup()
    plot(x, y_a, type = "n",
         ylim = c(if (input$show_obs) -0.14 * ymax else 0, 1.13 * ymax),
         xlab = "Individual measurement", ylab = "Density",
         main = "1  Population distributions")
    polygon(c(x, rev(x)), c(pmin(y_a, y_b), rep(0, length(x))),
            col = adjustcolor(col_null, alpha.f = 0.20), border = NA)
    lines(x, y_a, col = col_A, lwd = 2.6)
    lines(x, y_b, col = col_B, lwd = 2.6)
    abline(v = c(0, delta), col = c(col_A, col_B), lty = 3)
    if (input$show_obs) {
      points(s$A, -(0.045 + (seq_along(s$A) %% 6) * 0.012) * ymax,
             pch = 16, cex = 0.40, col = adjustcolor(col_A, 0.40))
      points(s$B, -(0.045 + (seq_along(s$B) %% 6) * 0.012) * ymax,
             pch = 16, cex = 0.40, col = adjustcolor(col_B, 0.40))
    }
    legend("topright",
           c(sprintf("Group A (SD %.2f; n %d)", sigma_a, input$n_a),
             sprintf("Group B (SD %.2f; n %d)", sigma_b, input$n_b)),
           col = c(col_A, col_B), lwd = 2.5, bty = "n", cex = 0.72)
  })

  output$sampling_plot <- renderPlot({
    r <- result()
    delta <- input$delta
    se <- r$theoretical_se
    x <- seq(min(0, delta) - 4.2 * se,
             max(0, delta) + 4.2 * se, length.out = 650L)
    h0 <- dnorm(x, 0, se)
    h1 <- dnorm(x, delta, se)
    plot_setup()
    plot(x, h0, type = "n", ylim = c(0, max(h0, h1) * 1.13),
         xlab = "Estimated difference in means (B - A)", ylab = "Density",
         main = "2  Sampling variability")
    lines(x, h0, col = col_null, lwd = 2.6)
    lines(x, h1, col = col_B, lwd = 2.6)
    abline(v = r$observed_diff, lty = 2, lwd = 1.8, col = col_p)
    legend("topright",
           legend = c("If H0 is true", "If selected difference is true",
                      "Observed estimate"),
           col = c(col_null, col_B, col_p), lty = c(1, 1, 2),
           lwd = c(2.5, 2.5, 1.8), bty = "n", cex = 0.77)
  })

  output$pvalue_plot <- renderPlot({
    test <- result()$welch
    t_obs <- abs(unname(test$statistic))
    df <- unname(test$parameter)
    critical <- qt(1 - input$alpha / 2, df = df)
    limit <- max(4.2, min(10, t_obs + 0.8))
    x <- seq(-limit, limit, length.out = 850L)
    density <- dt(x, df = df)
    plot_setup()
    plot(x, density, type = "n", ylim = c(0, max(density) * 1.17),
         xlab = "Welch t statistic under H0 (approx.)", ylab = "Density",
         main = "3  Welch two-sided p-value")
    if (t_obs < limit) {
      xx_left <- seq(-limit, -t_obs, length.out = 200L)
      xx_right <- seq(t_obs, limit, length.out = 200L)
      polygon(c(xx_left[1], xx_left, tail(xx_left, 1)),
              c(0, dt(xx_left, df), 0),
              col = adjustcolor(col_p, 0.32), border = NA)
      polygon(c(xx_right[1], xx_right, tail(xx_right, 1)),
              c(0, dt(xx_right, df), 0),
              col = adjustcolor(col_p, 0.32), border = NA)
      abline(v = c(-t_obs, t_obs), col = col_p, lty = 2, lwd = 1.6)
    }
    lines(x, density, col = col_null, lwd = 2.3)
    abline(v = c(-critical, critical), lty = 3, col = col_B, lwd = 1.5)
    legend("topright",
           legend = c("Approximate null distribution",
                      "Observed |Welch t| (p tails)", "Critical values"),
           col = c(col_null, col_p, col_B), lty = c(1, 2, 3),
           lwd = c(2.4, 1.7, 1.5), bty = "n", cex = 0.73)
    if (t_obs >= limit)
      mtext("Observed |t| beyond plotted range", side = 1,
            line = 3.2, cex = 0.66, col = col_p)
  })

  output$power_plot <- renderPlot({
    mc <- power_curves()
    d <- mc$design
    chosen <- input$extra_tests
    wilcox_curve <- if ("wilcoxon" %in% chosen) wilcoxon_powers() else NULL
    ks_curve <- if ("ks" %in% chosen) ks_power_results() else NULL
    selected_n <- input$n_a + input$n_b

    plot_setup()
    plot(d$total, mc$estimates[, "welch"], type = "l", lwd = 2.8,
         col = col_A, ylim = c(0, 1), xlim = c(10, 600),
         xlab = "Total N (n_A : n_B approximately fixed)",
         ylab = "Probability of p < alpha",
         main = "4  Rejection rates / statistical power")
    abline(h = 0.8, col = col_B, lty = 3, lwd = 1.2)
    abline(h = input$alpha, col = col_null, lty = 3, lwd = 1.2)
    abline(v = selected_n, col = adjustcolor(col_null, 0.38), lty = 2)
    leg_text <- "Welch t (Monte Carlo)"
    leg_col <- col_A
    leg_lty <- 1

    if (isTRUE(input$show_student)) {
      lines(d$total, mc$estimates[, "student"], col = col_student,
            lwd = 2.5, lty = 2)
      points(selected_n, mc$estimates[mc$selected, "student"],
             pch = 19, col = col_student, cex = 1.12)
      leg_text <- c(leg_text, "Student t (Monte Carlo)")
      leg_col <- c(leg_col, col_student)
      leg_lty <- c(leg_lty, 2)
    }
    if (!is.null(wilcox_curve)) {
      lines(d$total, wilcox_curve, col = col_wilcox, lwd = 2.4, lty = 3)
      points(selected_n, wilcox_curve[mc$selected],
             pch = 19, col = col_wilcox, cex = 1.12)
      leg_text <- c(leg_text, "Wilcoxon (approx.)")
      leg_col <- c(leg_col, col_wilcox)
      leg_lty <- c(leg_lty, 3)
    }
    if (!is.null(ks_curve)) {
      lines(ks_curve$n, ks_curve$power, col = col_ks, lwd = 2.2)
      points(ks_curve$n, ks_curve$power, col = col_ks,
             pch = 16, cex = 0.35)
      points(selected_n, ks_power_at_n(),
             pch = 19, col = col_ks, cex = 1.12)
      leg_text <- c(leg_text, "KS (Monte Carlo)")
      leg_col <- c(leg_col, col_ks)
      leg_lty <- c(leg_lty, 1)
    }
    points(selected_n, mc$estimates[mc$selected, "welch"],
           pch = 19, cex = 1.25, col = col_A)
    legend("bottomright", legend = c(leg_text, "80% reference", "Alpha"),
           col = c(leg_col, col_B, col_null),
           lty = c(leg_lty, 3, 3),
           lwd = c(rep(2.4, length(leg_text)), 1.2, 1.2),
           bty = "n", cex = 0.66, bg = "white")
  })

  output$power_method_note <- renderUI({
    chosen <- input$extra_tests
    unequal_sds <- abs(input$sigma_a - input$sigma_b) > 1e-9
    p(class = "test-note",
      sprintf("Welch and Student: %s Monte Carlo repetitions per N design. Total N grows with approximately the current n_A:n_B ratio. The selected design is simulated exactly.",
              format(parametric_mc_repetitions, big.mark = ",")),
      if ("wilcoxon" %in% chosen)
        " Wilcoxon: normal approximation to U-statistic moments under unequal n and SD; caution with small groups.",
      if ("ks" %in% chosen)
        sprintf(" KS: %d Monte Carlo repetitions per grid point; lines may be jagged.",
                ks_repetitions),
      if (unequal_sds)
        " Unequal SD: Wilcoxon and KS test FULL distribution equality; even delta=0 is not their null. Student may show an inflated or deflated false-positive rate.",
      " A higher rejection rate is not necessarily better if Type I error is inflated."
    )
  })

  output$interpretation <- renderUI({
    r <- result()
    mc <- power_curves()
    rates <- mc$estimates[mc$selected, ]
    extras <- extra_results()
    alpha <- input$alpha
    labels <- "Welch t-test (default)"
    hypotheses <- "Equality of population means (no equal-variance assumption)"
    stats <- sprintf("t = %.3f; df = %.1f",
                     unname(r$welch$statistic), unname(r$welch$parameter))
    p_values <- r$welch$p.value
    rate_labels <- sprintf("%.1f%% (Monte Carlo)", 100 * rates["welch"])
    ci <- unname(r$welch$conf.int)
    ci_labels <- sprintf("[%.3f, %.3f] (mean difference)", ci[1], ci[2])

    if (isTRUE(input$show_student)) {
      st <- r$student
      ci <- unname(st$conf.int)
      labels <- c(labels, "Student pooled t-test")
      hypotheses <- c(hypotheses,
                      "Equality of means (assumes equal population variances)")
      stats <- c(stats, sprintf("t = %.3f; df = %.0f",
                               unname(st$statistic), unname(st$parameter)))
      p_values <- c(p_values, st$p.value)
      rate_labels <- c(rate_labels, sprintf("%.1f%% (Monte Carlo)",
                                            100 * rates["student"]))
      ci_labels <- c(ci_labels,
                     sprintf("[%.3f, %.3f] (mean difference)", ci[1], ci[2]))
    }
    if (!is.null(extras$wilcoxon)) {
      w <- extras$wilcoxon
      labels <- c(labels, "Wilcoxon rank-sum")
      hypotheses <- c(hypotheses, "Equal population distributions; not just equal means")
      stats <- c(stats, sprintf("W = %.1f", unname(w$statistic)))
      p_values <- c(p_values, w$p.value)
      rate_labels <- c(rate_labels, sprintf("%.1f%% (approx.)",
                      100 * wilcoxon_powers()[mc$selected]))
      ci_labels <- c(ci_labels, "No mean-difference CI from this test")
    }
    if (!is.null(extras$ks)) {
      k <- extras$ks
      labels <- c(labels, "Kolmogorov-Smirnov")
      hypotheses <- c(hypotheses, "Equal population CDFs / distributions")
      stats <- c(stats, sprintf("D = %.3f", unname(k$statistic)))
      p_values <- c(p_values, k$p.value)
      rate_labels <- c(rate_labels, sprintf("%.1f%% (Monte Carlo)",
                      100 * ks_power_at_n()))
      ci_labels <- c(ci_labels, "No mean-difference CI from this test")
    }

    decision <- ifelse(p_values < alpha, "Reject H0 (significant)",
                       "Do not reject H0")
    div(class = "explain-panel",
      h4("Compare tests on exactly the SAME observed samples"),
      render_comparison_table(labels,
        c("Null hypothesis", "Test statistic / degrees of freedom",
          "Two-sided p-value", sprintf("Decision at alpha = %.2f", alpha),
          "Rejection probability at selected design",
          sprintf("%.0f%% confidence interval", 100 * (1 - alpha))),
        list(hypotheses, stats,
             vapply(p_values, format_p, character(1)),
             decision, rate_labels, ci_labels)
      ),
      p(sprintf("The observed difference (B - A) is %.3f, versus the true population difference %.3f. The true variance ratio Var(B)/Var(A) is %.2f.",
                r$observed_diff, input$delta,
                (input$sigma_b / input$sigma_a)^2)),
      p("Welch's test uses separate variance estimates and an approximated number of degrees of freedom; Student pools the two sample variances. Neither a nonsignificant p-value nor a confidence interval covering zero proves equality."),
      if (isTRUE(input$show_student)) p(
        tags$b("Do not select whichever test gives the smaller p-value. "),
        "With unequal population SDs, pooled Student confidence intervals can have nonnominal coverage, most markedly if group sizes also differ."),
      if ("wilcoxon" %in% input$extra_tests || "ks" %in% input$extra_tests)
        p("Wilcoxon and KS address equality of distributions; unequal SDs can lead to genuine distributional differences even when delta = 0. Such rejections are NOT Type I errors for these distributional hypotheses."),
      tags$hr(),
      p("Power is the long-run rejection probability under a specified alternative. At delta = 0, the Welch and Student rejection frequencies instead describe their Type I error under H0 (equal means). Because the Student reference distribution may be wrong for unequal variances, apparent high power alone is not evidence of a superior test.")
    )
  })

  output$null_error_panel <- renderUI({
    rates <- null_rejection()
    show_student <- isTRUE(input$show_student)
    labels <- if (show_student) c("Welch (default)", "Student (pooled)") else "Welch (default)"
    vals <- if (show_student) rates[c("welch", "student")] else rates["welch"]
    div(class = "explain-panel",
      h4("Separate experiment: Type I error when the TRUE mean difference is zero"),
      p(sprintf("Keeping n_A = %d, n_B = %d, SD_A = %.2f and SD_B = %.2f, we generated %s independent studies with mu_A = mu_B = 0, even if the delta slider above is nonzero.",
                input$n_a, input$n_b, input$sigma_a, input$sigma_b,
                format(parametric_null_repetitions, big.mark = ","))),
      render_comparison_table(labels,
        c("Empirical Type I error rate", "Nominal alpha", "Difference from alpha"),
        list(sprintf("%.2f%%", 100 * vals),
             rep(sprintf("%.2f%%", 100 * input$alpha), length(vals)),
             sprintf("%+.2f percentage points", 100 * (vals - input$alpha)))
      ),
      p("These are Monte Carlo estimates with sampling uncertainty. Welch is approximately calibrated for normal data with unequal variances; Student can reject too often or too seldom. A high null-rejection rate is a flaw, not increased power."),
      if (!show_student)
        p("Tick 'Also show Student's pooled t-test' to compare the tests under the identical true null model.")
    )
  })

  output$coverage_metrics <- renderUI({
    r <- coverage_results()
    w <- r$welch
    div(class = "metric-grid",
      metric_card("Welch observed CI coverage",
                  sprintf("%.1f%%", 100 * mean(w$covered)),
                  sprintf("%d/%d contain true delta", sum(w$covered), r$m), col_A),
      metric_card("Welch significant results",
                  sprintf("%.1f%%", 100 * mean(w$significant)),
                  sprintf("%d/%d reject H0", sum(w$significant), r$m), col_p),
      if (isTRUE(input$show_student))
        metric_card("Student observed CI coverage",
                    sprintf("%.1f%%", 100 * mean(r$student$covered)),
                    sprintf("%d/%d contain true delta", sum(r$student$covered), r$m),
                    col_student),
      if (isTRUE(input$show_student))
        metric_card("Student significant results",
                    sprintf("%.1f%%", 100 * mean(r$student$significant)),
                    sprintf("%d/%d reject H0", sum(r$student$significant), r$m),
                    col_student),
      metric_card("Nominal CI coverage", sprintf("%.1f%%", 100 * (1 - r$alpha)),
                  "Not a guarantee for the misspecified Student interval"),
      metric_card("True population mean difference", sprintf("%+.2f", r$delta),
                  "Null value for mean difference: 0")
    )
  })

  output$ci_plot_ui <- renderUI({
    r <- coverage_results()
    count <- if (isTRUE(input$show_all_ci)) r$m else min(100L, r$m)
    plot_height <- max(380L, 9L * count + 100L)
    plotOutput("ci_plot", height = paste0(plot_height, "px"))
  })

  output$ci_plot_context <- renderText({
    r <- coverage_results()
    count <- if (isTRUE(input$show_all_ci)) r$m else min(100L, r$m)
    sprintf("Showing %d of %d studies, with n_A = %d and n_B = %d. All %d studies contribute to the summaries. Confidence level: %.0f%%. %s",
            count, r$m, r$n_a, r$n_b, r$m, 100 * (1 - r$alpha),
            if (isTRUE(input$show_student))
              "Solid = Welch; dashed = Student (same independent studies)." else
              "Welch intervals; enable Student to compare methods.")
  })

  output$ci_plot <- renderPlot({
    r <- coverage_results()
    count <- if (isTRUE(input$show_all_ci)) r$m else min(100L, r$m)
    idx <- seq_len(count)
    both <- isTRUE(input$show_student)
    x_range <- range(c(0, r$delta,
                       r$welch$lower[idx], r$welch$upper[idx],
                       if (both) r$student$lower[idx],
                       if (both) r$student$upper[idx]))
    x_padding <- max(diff(x_range) * 0.06,
                     min(input$sigma_a, input$sigma_b) * 0.12)
    plot_setup()
    par(mar = c(4.2, 4.5, 3, 0.9))
    plot(NA, xlim = c(x_range[1] - x_padding, x_range[2] + x_padding),
         ylim = c(count + 0.5, 0.5),
         xlab = "Estimated mean difference (B - A)",
         ylab = "Study sample (independent experiment)",
         yaxt = "n", bty = "l",
         main = sprintf("%.0f%% confidence intervals: Welch%s",
                        100 * (1 - r$alpha),
                        if (both) " vs Student" else ""))
    y_ticks <- pretty(c(1, count), n = 8)
    y_ticks <- y_ticks[y_ticks >= 1 & y_ticks <= count]
    axis(2, at = y_ticks, labels = y_ticks, las = 1)
    abline(v = 0, col = col_null, lty = 3, lwd = 2)
    abline(v = r$delta, col = col_true, lty = 2, lwd = 2)

    draw_method <- function(method, offset, line_type) {
      y <- idx + offset
      segments(method$lower[idx], y, method$upper[idx], y,
               col = ifelse(method$covered[idx], col_A, col_B),
               lwd = if (both) 1.7 else 2.0, lty = line_type)
      not_sig <- which(!method$significant[idx])
      sig <- which(method$significant[idx])
      if (length(not_sig) > 0)
        points(r$estimated_diff[not_sig], y[not_sig],
               pch = 1, col = col_null, cex = 0.60)
      if (length(sig) > 0)
        points(r$estimated_diff[sig], y[sig],
               pch = 21, col = col_p, bg = col_p, cex = 0.60)
    }
    draw_method(r$welch, if (both) -0.18 else 0, 1)
    if (both) draw_method(r$student, +0.18, 2)
  }, res = 110)

  output$running_rates_plot <- renderPlot({
    r <- coverage_results()
    point <- power_curves()
    expected <- point$estimates[point$selected, ]
    k <- seq_len(r$m)
    cov_w <- cumsum(r$welch$covered) / k
    sig_w <- cumsum(r$welch$significant) / k
    plot_setup()
    plot(k, cov_w, type = "l", col = col_A, lwd = 2.5,
         ylim = c(0, 1), xlab = "Number of experiments",
         ylab = "Cumulative proportion", bty = "l",
         main = "How observed proportions stabilize")
    lines(k, sig_w, col = col_p, lwd = 2.5)
    abline(h = 1 - r$alpha, col = col_null, lty = 3, lwd = 1.5)
    abline(h = expected["welch"], col = col_p, lty = 3, lwd = 1.4)
    leg <- c("Welch: observed coverage", "Welch: reject H0",
             "Nominal coverage", "Welch: expected rejection (MC)")
    cols <- c(col_A, col_p, col_null, col_p)
    ltys <- c(1, 1, 3, 3)
    if (isTRUE(input$show_student)) {
      lines(k, cumsum(r$student$covered) / k,
            col = col_wilcox, lwd = 2.3, lty = 2)
      lines(k, cumsum(r$student$significant) / k,
            col = col_student, lwd = 2.3, lty = 2)
      abline(h = expected["student"], col = col_student, lty = 3, lwd = 1.3)
      leg <- c(leg, "Student: observed coverage", "Student: reject H0",
               "Student: expected rejection (MC)")
      cols <- c(cols, col_wilcox, col_student, col_student)
      ltys <- c(ltys, 2, 2, 3)
    }
    legend("right", legend = leg, col = cols, lty = ltys,
           lwd = 2.0, bg = "white", cex = 0.64)
  })

  output$coverage_interpretation <- renderUI({
    r <- coverage_results()
    mc <- power_curves()
    expectation <- mc$estimates[mc$selected, ]
    methods <- if (isTRUE(input$show_student))
      c("Welch (default)", "Student pooled") else "Welch (default)"
    info <- if (isTRUE(input$show_student))
      list(r$welch, r$student) else list(r$welch)
    target <- if (r$delta == 0) "Estimated null rejection" else
      "Estimated rejection under alternative"

    div(class = "explain-panel",
      h4("Interpretation: CI coverage, rejection, and test assumptions"),
      render_comparison_table(methods,
        c("Number of studies",
          sprintf("Observed %.0f%%-CI coverage", 100 * (1-r$alpha)),
          "Observed rejection frequency",
          target,
          "Nominal CI coverage"),
        list(rep(as.character(r$m), length(info)),
             vapply(info, function(x) sprintf("%.1f%% (%d/%d)",
                100 * mean(x$covered), sum(x$covered), r$m), character(1)),
             vapply(info, function(x) sprintf("%.1f%% (%d/%d)",
                100 * mean(x$significant), sum(x$significant), r$m), character(1)),
             sprintf("%.1f%% (MC)", 100 * expectation[
               if (length(info) == 2) c("welch", "student") else "welch"]),
             rep(sprintf("%.1f%%", 100 * (1 - r$alpha)), length(info)))
      ),
      p(sprintf("Each row in the forest plot is an independent experiment. All %d experiments have the SAME selected population parameters and actual mean difference %.2f. Their sample means and standard errors vary randomly.", r$m, r$delta)),
      p("Coverage means that the CI contains the TRUE difference delta. Significance means that the CI excludes the NULL value zero. Both methods use t confidence intervals corresponding exactly to their own reported two-sided p-values."),
      if (r$delta == 0) p(
        "Here the true difference equals zero, so every rejected mean-equality null is a false positive; the CI misses the true effect exactly when the corresponding test rejects. The Welch procedure is approximately calibrated, whereas Student's size may be distorted by unequal SDs and unequal n."),
      if (r$delta != 0) p(
        "When the true difference is nonzero, a CI may cover delta and exclude zero simultaneously. Its coverage and its significance address two different questions. The dotted rejection references are separate Monte Carlo estimates, not exact theoretical powers."),
      if (isTRUE(input$show_student)) p(
        tags$b("Compare Student with Welch: "),
        "Both CIs use the SAME generated studies, so observed differences stem only from how their standard errors and degrees of freedom are calculated. The pooled Student interval assumes equal population variances."),
      p("The nominal confidence level is a property of the repeated sampling procedure, not a probability assigned to the fixed true parameter after the data have been observed. A larger batch generally yields more stable observed rates.")
    )
  })

  # ---- Independent categorical observations (2x2 Pearson / Yates) ----
  independent_uniforms <- reactive({
    set.seed(20261201 + input$resample_categorical)
    list(A = runif(300L), B = runif(300L))
  })

  categorical_result <- reactive({
    u <- independent_uniforms()
    n <- input$n
    a_yes <- sum(u$A[seq_len(n)] < input$prob_a)
    b_yes <- sum(u$B[seq_len(n)] < input$prob_b)
    tab <- matrix(c(a_yes, n - a_yes, b_yes, n - b_yes),
                  nrow = 2, byrow = TRUE,
                  dimnames = list(Group = c("A", "B"),
                                  Outcome = c("Yes", "No")))
    valid <- all(colSums(tab) > 0)
    pearson <- yates <- NULL
    if (valid) {
      pearson <- suppressWarnings(chisq.test(tab, correct = FALSE))
      yates <- suppressWarnings(chisq.test(tab, correct = TRUE))
    }
    phi <- phi_2x2(tab)
    list(tab = tab, valid = valid, pearson = pearson, yates = yates,
         phi = phi, cramer_v = abs(phi),
         min_expected = if (valid) min(pearson$expected) else 0,
         positive_a = a_yes / n, positive_b = b_yes / n)
  })

  categorical_power <- reactive({
    pa <- input$prob_a
    pb <- input$prob_b
    alpha <- input$alpha
    set.seed(20261202)
    curve <- matrix(NA_real_, nrow = length(power_grid_categorical), ncol = 2L)
    for (i in seq_along(power_grid_categorical)) {
      ni <- power_grid_categorical[i]
      a <- rbinom(mc_repetitions, size = ni, prob = pa)
      b <- rbinom(mc_repetitions, size = ni, prob = pb)
      rejects <- chisq_rejections_2x2(a, b, ni, alpha)
      curve[i, ] <- c(mean(rejects$uncorrected), mean(rejects$corrected))
    }
    list(n = power_grid_categorical, powers = curve)
  })

  output$categorical_metrics <- renderUI({
    r <- categorical_result()
    div(class = "metric-grid",
      metric_card("Pearson chi-square p", if (r$valid) format_p(r$pearson$p.value) else "N/A",
                  "Without continuity correction"),
      metric_card("Yates-corrected p", if (r$valid) format_p(r$yates$p.value) else "N/A",
                  "Same table; continuity correction"),
      metric_card("Phi (signed)", fmt_stat(r$phi),
                  "Sign depends on table coding"),
      metric_card("Cramer's V", fmt_stat(r$cramer_v),
                  "0 to 1; for 2x2, V = |phi|"),
      metric_card("True risk difference", sprintf("%+.2f", input$prob_b - input$prob_a),
                  "P(Yes|B) minus P(Yes|A)")
    )
  })

  output$categorical_table <- renderTable({
    r <- categorical_result()
    as.data.frame.matrix(r$tab)
  }, rownames = TRUE, striped = TRUE, bordered = TRUE, spacing = "s")

  output$categorical_bar_plot <- renderPlot({
    r <- categorical_result()
    plot_setup()
    mid <- barplot(c(r$positive_a, r$positive_b), ylim = c(0, 1),
                   names.arg = c("Group A", "Group B"),
                   col = c(col_A, col_B), border = NA,
                   ylab = "Observed proportion Yes", main = "Observed and true proportions")
    points(mid, c(input$prob_a, input$prob_b), pch = 4, lwd = 2.4,
           cex = 1.6, col = col_null)
    legend("topright", legend = c("Observed proportion", "True population P(Yes)"),
           pch = c(15, 4), col = c(col_B, col_null), bty = "n", cex = 0.79)
  })

  output$categorical_null_plot <- renderPlot({
    r <- categorical_result()
    stats <- if (r$valid) c(unname(r$pearson$statistic), unname(r$yates$statistic))
             else c(NA_real_, NA_real_)
    plot_chi1_pvalues(stats,
                     c("Pearson chi-square", "Yates-corrected"),
                     c(col_independent, col_corrected),
                     "Chi-square null reference (df = 1)")
  })

  output$categorical_power_plot <- renderPlot({
    power <- categorical_power()
    plot_setup()
    plot(power$n, power$powers[, 1], type = "l", lwd = 2.6,
         col = col_independent, ylim = c(0, 1), xlim = c(5, 300),
         xlab = "Sample size per independent group (n)",
         ylab = "Rejection probability", bty = "l",
         main = "Power: Pearson vs. Yates correction")
    lines(power$n, power$powers[, 2], col = col_corrected, lwd = 2.4, lty = 2)
    abline(h = input$alpha, col = col_null, lty = 3)
    abline(h = 0.8, col = col_B, lty = 3)
    abline(v = input$n, col = adjustcolor(col_null, 0.40), lty = 3)
    points(input$n, approx(power$n, power$powers[, 1], xout = input$n)$y,
           pch = 19, col = col_independent)
    points(input$n, approx(power$n, power$powers[, 2], xout = input$n)$y,
           pch = 19, col = col_corrected)
    legend("bottomright", legend = c("Without correction", "With Yates correction"),
           col = c(col_independent, col_corrected), lty = c(1, 2),
           lwd = 2.5, bty = "n", cex = 0.80)
  })

  output$categorical_interpretation <- renderUI({
    r <- categorical_result()
    power <- categorical_power()
    powers <- c(approx(power$n, power$powers[, 1], xout = input$n)$y,
                approx(power$n, power$powers[, 2], xout = input$n)$y)
    pval <- if (r$valid) c(r$pearson$p.value, r$yates$p.value)
            else c(NA_real_, NA_real_)
    chi <- if (r$valid) c(unname(r$pearson$statistic), unname(r$yates$statistic))
           else c(NA_real_, NA_real_)
    div(class = "explain-panel",
      h4("Interpretation: independent binary outcomes"),
      render_comparison_table(
        c("Pearson chi-square", "Yates correction"),
        c("H0", "Test statistic (df = 1)", "p-value", "Decision",
          "Power at selected n"),
        list(c("P(Yes|A) = P(Yes|B)", "P(Yes|A) = P(Yes|B)"),
             sprintf("Chi-square = %s", vapply(chi, fmt_stat, character(1))),
             vapply(pval, fmt_optional_p, character(1)),
             ifelse(is.na(pval), "Cannot test (no outcome variation)",
                    ifelse(pval < input$alpha, "Reject H0", "Do not reject H0")),
             sprintf("%.1f%% (Monte Carlo)", 100 * powers))
      ),
      p(sprintf("Observed proportions: group A = %.1f%%, group B = %.1f%%. Population probabilities: %.1f%% vs. %.1f%%.",
                100 * r$positive_a, 100 * r$positive_b,
                100 * input$prob_a, 100 * input$prob_b)),
      p(sprintf("Phi = %s; Cramer's V = %s. For a 2x2 table, the absolute phi coefficient equals Cramer's V; they are not two different statistical tests.",
                fmt_stat(r$phi), fmt_stat(r$cramer_v))),
      p("The sign of phi depends on the row/column ordering (here: A then B; Yes then No). Cramer's V is unsigned and measures association strength. Neither is a p-value."),
      if (!r$valid) p(tags$b("No variability: "),
                      "One of the outcome columns is empty. Chi-square statistics and phi/V are undefined for this observed table."),
      if (r$valid && r$min_expected < 5) p(tags$b("Small expected counts: "),
                      sprintf("The smallest expected cell count is %.2f. The chi-square p-values rely on an approximation that may be inaccurate here; Fisher's exact test is a common alternative.", r$min_expected)),
      p("Yates' correction typically reduces the chi-square statistic and makes the test more conservative. Monte Carlo curves are estimates, not exact power. All rows are independent in this tab.")
    )
  })

  # ---- Paired binary outcomes: one pair per study participant ----
  paired_uniforms <- reactive({
    set.seed(20261203 + input$resample_paired)
    runif(300L)
  })

  paired_result <- reactive({
    q <- input$paired_discordance
    r <- input$paired_direction
    concordant_yes <- input$paired_concordance
    p00 <- (1 - q) * (1 - concordant_yes)
    p01 <- q * r
    p10 <- q * (1 - r)
    p11 <- (1 - q) * concordant_yes
    boundaries <- c(p00, p00 + p01, p00 + p01 + p10)
    cell <- findInterval(paired_uniforms()[seq_len(input$n)], boundaries) + 1L
    tbl <- matrix(tabulate(cell, nbins = 4L), nrow = 2L, byrow = TRUE,
                  dimnames = list(A = c("No", "Yes"), B = c("No", "Yes")))
    b <- tbl[1, 2]    # A=No, B=Yes
    c <- tbl[2, 1]    # A=Yes, B=No
    discordant <- b + c
    uncorrected <- corrected <- NULL
    if (discordant > 0) {
      uncorrected <- mcnemar.test(tbl, correct = FALSE)
      corrected <- mcnemar.test(tbl, correct = TRUE)
    }
    exact_p <- if (discordant > 0) binom.test(b, discordant, p = 0.5)$p.value else 1
    list(table = tbl, b = b, c = c, discordant = discordant,
         uncorrected = uncorrected, corrected = corrected,
         exact_p = exact_p, p00 = p00, p01 = p01, p10 = p10, p11 = p11,
         true_change = p01 - p10,
         observed_change = (b - c) / input$n)
  })

  paired_power <- reactive({
    q <- input$paired_discordance
    r <- input$paired_direction
    alpha <- input$alpha
    set.seed(20261204)
    curve <- matrix(NA_real_, nrow = length(power_grid_categorical), ncol = 3L)
    for (i in seq_along(power_grid_categorical)) {
      ni <- power_grid_categorical[i]
      k <- rbinom(mc_repetitions, size = ni, prob = q)
      b <- rbinom(mc_repetitions, size = k, prob = r)
      rejected <- mcnemar_rejections(k, b, alpha)
      curve[i, ] <- c(mean(rejected$uncorrected), mean(rejected$corrected),
                      mean(rejected$exact))
    }
    list(n = power_grid_categorical, powers = curve)
  })

  output$paired_metrics <- renderUI({
    r <- paired_result()
    div(class = "metric-grid",
      metric_card("McNemar p (no correction)",
                  if (r$discordant > 0) format_p(r$uncorrected$p.value) else "N/A",
                  "Asymptotic chi-square(1)"),
      metric_card("McNemar p (corrected)",
                  if (r$discordant > 0) format_p(r$corrected$p.value) else "N/A",
                  "Continuity correction"),
      metric_card("Exact McNemar p", format_p(r$exact_p),
                  "Two-sided exact binomial"),
      metric_card("Discordant pairs", as.character(r$discordant),
                  sprintf("of %d pairs", input$n)),
      metric_card("True marginal change", sprintf("%+.2f", r$true_change),
                  "P(Yes at B) - P(Yes at A)")
    )
  })

  output$paired_table <- renderTable({
    as.data.frame.matrix(paired_result()$table)
  }, rownames = TRUE, striped = TRUE, bordered = TRUE, spacing = "s")

  output$paired_counts_plot <- renderPlot({
    r <- paired_result()
    plot_setup()
    barplot(c(r$b, r$c), names.arg = c("No to Yes", "Yes to No"),
            col = c(col_A, col_B), border = NA,
            ylim = c(0, max(2, r$b, r$c) * 1.25),
            ylab = "Number of discordant pairs", main = "Only discordances enter McNemar")
  })

  output$paired_null_plot <- renderPlot({
    r <- paired_result()
    stats <- if (r$discordant > 0)
      c(unname(r$uncorrected$statistic), unname(r$corrected$statistic))
      else c(NA_real_, NA_real_)
    plot_chi1_pvalues(stats,
                     c("Uncorrected McNemar", "Corrected McNemar"),
                     c(col_independent, col_corrected),
                     "McNemar null reference (df = 1)")
  })

  output$paired_power_plot <- renderPlot({
    r <- paired_power()
    plot_setup()
    plot(r$n, r$powers[, 1], type = "l", lwd = 2.6, col = col_independent,
         ylim = c(0, 1), xlim = c(5, 300),
         xlab = "Number of paired subjects (n)", ylab = "Rejection probability",
         bty = "l", main = "Power: three versions of McNemar")
    lines(r$n, r$powers[, 2], col = col_corrected, lwd = 2.3, lty = 2)
    lines(r$n, r$powers[, 3], col = col_exact, lwd = 2.3, lty = 3)
    abline(h = input$alpha, col = col_null, lty = 3)
    abline(h = 0.8, col = col_B, lty = 3)
    abline(v = input$n, col = adjustcolor(col_null, 0.40), lty = 3)
    for (j in 1:3) {
      points(input$n, approx(r$n, r$powers[, j], xout = input$n)$y,
             pch = 19, col = c(col_independent, col_corrected, col_exact)[j])
    }
    legend("bottomright",
           legend = c("Uncorrected", "Continuity-corrected", "Exact binomial"),
           col = c(col_independent, col_corrected, col_exact),
           lty = 1:3, lwd = 2.4, bty = "n", cex = 0.79)
  })

  output$paired_interpretation <- renderUI({
    r <- paired_result()
    power <- paired_power()
    powers <- vapply(1:3, function(i)
      approx(power$n, power$powers[, i], xout = input$n)$y, numeric(1))
    pval <- c(if (r$discordant > 0) r$uncorrected$p.value else NA_real_,
              if (r$discordant > 0) r$corrected$p.value else NA_real_,
              r$exact_p)
    stats <- c(if (r$discordant > 0) unname(r$uncorrected$statistic) else NA_real_,
               if (r$discordant > 0) unname(r$corrected$statistic) else NA_real_,
               NA_real_)
    div(class = "explain-panel",
      h4("Interpretation: repeated binary observations from the SAME subjects"),
      render_comparison_table(
        c("McNemar uncorrected", "McNemar corrected", "Exact McNemar"),
        c("Null hypothesis", "Test statistic", "p-value", "Decision",
          "Power at selected n"),
        list(rep("P(No -> Yes) = P(Yes -> No)", 3),
             c(sprintf("Chi-square = %s", fmt_stat(stats[1])),
               sprintf("Chi-square = %s", fmt_stat(stats[2])),
               "Binomial count of discordances"),
             vapply(pval, fmt_optional_p, character(1)),
             ifelse(is.na(pval), "Not estimable (0 discordant pairs)",
                    ifelse(pval < input$alpha, "Reject H0", "Do not reject H0")),
             sprintf("%.1f%% (Monte Carlo)", 100 * powers))
      ),
      p(sprintf("Observed: %d No-to-Yes transitions and %d Yes-to-No transitions (total %d discordant pairs). True expected marginal Yes-change is %+.1f percentage points; observed change is %+.1f points.",
                r$b, r$c, r$discordant, 100 * r$true_change,
                100 * r$observed_change)),
      p("Concordant pairs contribute to the sample size and the marginal rates but not to the McNemar statistic. Increasing discordance with the same imbalance can improve power."),
      if (r$discordant == 0) p(tags$b("No discordances: "),
                     "The asymptotic test statistics are undefined. We display exact p = 1 (no evidence of a difference)."),
      if (r$discordant > 0 && r$discordant < 25) p(tags$b("Few discordant pairs: "),
                     "Consider the exact binomial version; chi-square approximations can be inaccurate."),
      p("These are PAIRED data. A Pearson chi-square test assuming independent groups would ignore the within-subject pairing and is not a valid substitute."),
      p("For the exact test, the test statistic is the number of transitions in one direction conditional on the total discordances; its reference distribution is Binomial(k, 0.5), not chi-square.")
    )
  })

  # ---- Two-sample F-test: true ratio of population variances ----
  f_base_draws <- reactive({
    set.seed(20261205 + input$resample_f)
    list(A = rnorm(300L), B = rnorm(300L))
  })

  f_results <- reactive({
    z <- f_base_draws()
    n <- input$n
    ratio <- input$f_ratio
    a <- input$sigma * z$A[seq_len(n)]
    b <- input$sigma * sqrt(ratio) * z$B[seq_len(n)]
    test <- var.test(b, a, ratio = 1, alternative = "two.sided",
                     conf.level = 1 - input$alpha)
    list(a = a, b = b, test = test, sample_ratio = var(b) / var(a),
         true_ratio = ratio, exact_power = power_f_variance(n, ratio, input$alpha))
  })

  output$f_metrics <- renderUI({
    r <- f_results()
    div(class = "metric-grid",
      metric_card("Observed F statistic", sprintf("%.3f", unname(r$test$statistic)),
                  "s_B^2 / s_A^2"),
      metric_card("Two-sided F p-value", format_p(r$test$p.value),
                  if (r$test$p.value < input$alpha) "Reject equal variances" else "Do not reject equal variances"),
      metric_card("True variance ratio", sprintf("%.2f", r$true_ratio),
                  "Var(B) / Var(A)"),
      metric_card("Theoretical F power", sprintf("%.1f%%", 100 * r$exact_power),
                  "Exact under normality"),
      metric_card("Sample SD ratio", sprintf("%.3f", sd(r$b) / sd(r$a)),
                  "SD(B) / SD(A)")
    )
  })

  output$f_density_plot <- renderPlot({
    r <- f_results()
    sda <- input$sigma
    sdb <- sda * sqrt(input$f_ratio)
    xrange <- max(sda, sdb) * 4.4
    x <- seq(-xrange, xrange, length.out = 600)
    ya <- dnorm(x, sd = sda)
    yb <- dnorm(x, sd = sdb)
    plot_setup()
    plot(x, ya, type = "l", col = col_A, lwd = 2.6,
         ylim = c(0, max(ya, yb) * 1.12),
         xlab = "Individual observation", ylab = "Density",
         bty = "l", main = "Normal populations: same mean, different SD")
    lines(x, yb, col = col_B, lwd = 2.6)
    legend("topright", legend = c(sprintf("A: SD = %.2f", sda),
                                  sprintf("B: SD = %.2f", sdb)),
           col = c(col_A, col_B), lwd = 2.6, bty = "n", cex = 0.82)
  })

  output$f_null_plot <- renderPlot({
    r <- f_results()
    dfree <- input$n - 1
    observed <- unname(r$test$statistic)
    low <- qf(input$alpha / 2, dfree, dfree)
    high <- qf(1 - input$alpha / 2, dfree, dfree)
    xmax <- max(qf(0.995, dfree, dfree), min(25, observed * 1.15))
    x <- seq(0.0001, xmax, length.out = 700)
    y <- df(x, df1 = dfree, df2 = dfree)
    plot_setup()
    plot(x, y, type = "n", ylim = c(0, max(y) * 1.16),
         xlab = "F statistic under H0 (ratio = 1)", ylab = "Density",
         bty = "l", main = "Two-sided F-test")
    xl <- seq(0.0001, min(low, xmax), length.out = 160)
    polygon(c(xl[1], xl, tail(xl, 1)), c(0, df(xl, dfree, dfree), 0),
            col = adjustcolor(col_p, 0.30), border = NA)
    if (high < xmax) {
      xr <- seq(high, xmax, length.out = 160)
      polygon(c(xr[1], xr, tail(xr, 1)), c(0, df(xr, dfree, dfree), 0),
              col = adjustcolor(col_p, 0.30), border = NA)
    }
    lines(x, y, col = col_null, lwd = 2.5)
    abline(v = c(low, high), col = col_B, lty = 3, lwd = 1.7)
    if (observed <= xmax) abline(v = observed, col = col_f, lwd = 2.4)
    legend("topright", legend = c("Observed F", "Critical values", "Rejection areas"),
           col = c(col_f, col_B, col_p), lty = c(1, 3, 1), lwd = c(2.5, 1.8, 4),
           bty = "n", cex = 0.75)
    if (observed > xmax) mtext("Observed F lies beyond the plotted range",
                              side = 1, line = 3.1, cex = 0.65, col = col_f)
  })

  output$f_power_plot <- renderPlot({
    ns <- 5:300
    powers <- power_f_variance(ns, input$f_ratio, input$alpha)
    plot_setup()
    plot(ns, powers, type = "l", col = col_f, lwd = 2.7,
         ylim = c(0, 1), xlab = "Independent observations per group (n)",
         ylab = "Probability of rejecting equal variances",
         bty = "l", main = "Exact statistical power under normality")
    abline(h = c(input$alpha, 0.8), lty = 3,
           col = c(col_null, col_B))
    abline(v = input$n, col = adjustcolor(col_null, 0.40), lty = 3)
    points(input$n, powers[input$n - 4L], pch = 19, col = col_f, cex = 1.25)
  })

  output$f_interpretation <- renderUI({
    r <- f_results()
    ci <- unname(r$test$conf.int)
    div(class = "explain-panel",
      h4("Interpretation: F-test of equal population variances"),
      render_comparison_table(
        c("Variance-ratio F-test"),
        c("H0", "Test statistic", "Degrees of freedom", "Two-sided p-value",
          "Decision", "Power at selected n", "Confidence interval for Var(B)/Var(A)"),
        list("Var(B) / Var(A) = 1",
             sprintf("F = %.3f", unname(r$test$statistic)),
             sprintf("df1 = %d; df2 = %d", input$n - 1, input$n - 1),
             format_p(r$test$p.value),
             if (r$test$p.value < input$alpha) "Reject H0" else "Do not reject H0",
             sprintf("%.1f%% (exact under normality)", 100 * r$exact_power),
             sprintf("[%.3f, %.3f]", ci[1], ci[2]))
      ),
      p(sprintf("The true ratio Var(B)/Var(A) = %.2f, and this sample gives an estimated ratio of %.3f. The confidence interval excludes 1 exactly when the matching two-sided test rejects H0.",
                r$true_ratio, r$sample_ratio)),
      p("Unlike the t-test, the classical F-test is especially sensitive to departures from normality. In practice, variance equality can be assessed with more robust methods (e.g., a median-centered Levene/Brown-Forsythe test)."),
      p("Do not use a preliminary F-test to decide automatically between Student's and Welch's t-test: that two-stage procedure can distort inferential properties. Welch's t-test is often a sensible default when group variances may differ."),
      p("Changing the common scale sigma multiplies both variances by the same factor, leaving their ratio, the F statistic, p-value, and theoretical power unchanged.")
    )
  })

}

shinyApp(ui = ui, server = server)
